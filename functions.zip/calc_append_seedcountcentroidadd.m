%% SEEDED (in order) & counted centroid-add-one algorithm, get RT prediction
% early stop #1, early stop #2

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('results_39.mat')
sigma_s = 2;

for subjidx = 1:length(STIM)
    ks = Modelresults{39}.par_est(subjidx,[1:4]);

    for i_trial = 1:length(STIM{subjidx}.X)
        tic 
        % 
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        
        pigs = [x y];
        n = length(x);
        k = ks(find(n ==[6 9 12 15]));
        
        localpigweight = nan(1,n);
        for idx = 1:n
            localpigweight(idx) = sum(normpdf(x,x(idx),sigma_s)) .* sum(normpdf(y,y(idx),sigma_s));
        end
        
        [~, pigorder] = sort(localpigweight, 'descend');
        
        LLR_z       = [];
        z           = [];
        clustpts    = [];
        clustidcs   = [];
        centroid    = [];
        
        COUNT = 0;
        
        for i_seed = pigorder
            flag_threshold = 0;
            COUNT = COUNT + 1;

            % Initialize first cluster (single point)
            z              = zeros(1,n);
            z(i_seed)      = 1;
            clustpts       = pigs(i_seed,:);
            clustidcs      = i_seed;
            centroid       = clustpts;

            llr_z          = get_LLR_z(x,y,z);
            
            if llr_z > k
                tryimprove = 0;
            else
                tryimprove = 1;
            end

            while tryimprove
                COUNT = COUNT + 1;
                
                % Find next nearest point to current cluster
                pigs_ = pigs;
                pigs_([clustidcs],:) = inf; % Set previously clustered points to inf
                [~, NNindx] = min(pdist2(centroid,pigs_));

                % Try adding NN to form new cluster
                z_new           = z;
                z_new(NNindx)   = 1;
                clustpts_new    = [clustpts; pigs(NNindx,:)];
                clustidcs_new   = [clustidcs; NNindx];
                centroid_new    = mean(clustpts,1);

                % Get new LLR
                llr_z_new   = get_LLR_z(x,y,z_new);

                if llr_z_new > k
                    flag_threshold = 1;
                    break
                elseif llr_z_new <= llr_z
                    tryimprove = 0;
                else
                    tryimprove  = 1;

                    llr_z       = llr_z_new;
                    z           = z_new;
                    clustpts    = clustpts_new;
                    clustidcs   = clustidcs_new;
                    centroid    = centroid_new;
                end
            end
            
            if flag_threshold
                break
            end
        end
            
        STIM{subjidx}.k_count.seededcentroidadd(i_trial,1) = COUNT; 
        toc
    end
end

save('alldata.mat', 'DATA', 'STIM');