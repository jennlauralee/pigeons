%% func_mostlikelyz


function [bestLLR_z, best_z] = func_mostlikelyz(x,y,p_aff)

n = length(x); 

poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors 
nZ          = length(poss_z);
llrz        = nan(1, nZ);
maxllr      = [];
maxidx      = [];
maxz        = [];

for i_z = 1:nZ
    z = poss_z(i_z,:);
    llrz(i_z) = get_LLR_z_false_affiliation(x,y,z,p_aff);
end

[maxllr, maxidx] = max(llrz);
maxz = poss_z(maxidx,:);

best_z = maxz;
bestLLR_z = maxllr;
end


