function LLR_z_mu = func_maxz(x,y,mu,p_aff)

n = length(x);

poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors
nZ          = length(poss_z);

LLR_z_mu_ = get_LLR_zvec_mu_false_affiliation(x,y,poss_z,mu,p_aff);

LLR_z_mu = max(LLR_z_mu_);
end