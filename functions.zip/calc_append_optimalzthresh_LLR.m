%% calc_append_optimalzthresh_LLR

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

sigma_s     = 2;
R           = 10;

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        
            x   = STIM{subjidx}.X{i_trial};
            y   = STIM{subjidx}.Y{i_trial};
            
            opt_thresh = 1/pi/R^2;
            
            z   = STIM{subjidx}.maxmargmu.likelihood.C1_likelihoods{i_trial} > opt_thresh;
            mu  = STIM{subjidx}.maxmargmu.likelihood.mu(i_trial,:);
            STIM{subjidx}.maxmargmu.likelihood.opt_thresh_z = z;
            STIM{subjidx}.maxmargmu.likelihood.LLR_z_mu(i_trial) = get_LLR_z_mu(x,y,z,mu);
            
            clear z mu
            z   = STIM{subjidx}.maxmargmu.posterior.C1_likelihoods{i_trial} > opt_thresh;
            mu  = STIM{subjidx}.maxmargmu.posterior.mu(i_trial,:);
            STIM{subjidx}.maxmargmu.posterior.opt_thresh_z = z;
            STIM{subjidx}.maxmargmu.posterior.LLR_z_mu(i_trial) = get_LLR_z_mu(x,y,z,mu);
            
            clear z mu
            z   = STIM{subjidx}.localgaussgrid.C1_likelihoods{i_trial} > opt_thresh;
            mu  = STIM{subjidx}.localgaussgrid.mu(i_trial,:);
            STIM{subjidx}.localgaussgrid.opt_thresh_z = z;
            STIM{subjidx}.localgaussgrid.LLR_z_mu(i_trial) = get_LLR_z_mu(x,y,z,mu);
            
            clear z mu
            z   = STIM{subjidx}.MeanDist_Mu.C1_likelihoods{i_trial} > opt_thresh;
            mu  = STIM{subjidx}.MeanDist_Mu.trial(i_trial,:);
            STIM{subjidx}.MeanDist_Mu.opt_thresh_z = z;
            STIM{subjidx}.MeanDist_Mu.LLR_z_mu(i_trial) = get_LLR_z_mu(x,y,z,mu);
            
            clear z mu
            z   = STIM{subjidx}.EM.C1_likelihoods{i_trial} > opt_thresh;
            mu  = STIM{subjidx}.EM.mu(i_trial,:);
            STIM{subjidx}.EM.opt_thresh_z = z;
            STIM{subjidx}.EM.LLR_z_mu(i_trial) = get_LLR_z_mu(x,y,z,mu);
            
    end
end

save('alldata.mat', 'DATA', 'STIM');
                                              