%% SEEDED append centroid-add-one algorithm

%% 1. Start the closest pigeon to global centroid (not random); add nearest point to the centroid 
% until doing so doesn't increase the log likelihood ratio anymore.
% If that LLR_Z is the best agglomerative LLR_Z as determined by
% calc_append_centroidadd, then stop the iterations. Otherwise:

%% 2. Move onto next best starting pigeon (IN ORDER of proximity to the global centroid) until the best agglomerative LLR_Z (as determined by calc_append_centroidadd) is found 

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        
        best_LLR = STIM{subjidx}.centroidadd.LLR_z(i_trial); %actual best
        
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        pigs = [x y];
        n = length(x);
        global_centroid = mean(pigs);
        prox_pigdist = nan(n,1);
        
        for i_pig = 1:n
            prox_pigdist(i_pig) = pdist([pigs(i_pig,:); global_centroid]);
        end
        
        [~, prox_pigorder] = sort(prox_pigdist, 'ascend');
        
        LLR_z       = [];
        z           = [];
        clustpts    = [];
        clustidcs   = [];
        centroid    = [];
        
        COUNT = 0;
        
        for i_seed = prox_pigorder %1:n
            
            % Initialize first cluster (single point)
            z              = zeros(1,n);
            z(i_seed)      = 1;
            clustpts       = pigs(i_seed,:);
            clustidcs      = i_seed;
            centroid       = clustpts;
            
            llr_z          = get_LLR_z(x,y,z);
            
            tryimprove = 1;
            
            COUNT = COUNT + 1;

            while tryimprove
                
                % Find next nearest point to current cluster
                pigs_ = pigs;
                pigs_([clustidcs],:) = inf; % Set previously clustered points to inf
                [~, NNindx] = min(pdist2(centroid,pigs_));
                
                % Try adding NN to form new cluster
                z_new           = z;
                z_new(NNindx)   = 1;
                clustpts_new    = [clustpts; pigs(NNindx,:)];
                clustidcs_new   = [clustidcs; NNindx];
                centroid_new    = mean(clustpts,1);
                
                % Get new LLR
                llr_z_new   = get_LLR_z(x,y,z_new);
                
                if llr_z_new > llr_z
                    tryimprove  = 1;
                    COUNT = COUNT + 1;
                    
                    llr_z       = llr_z_new;
                    z           = z_new;
                    clustpts    = clustpts_new;
                    clustidcs   = clustidcs_new;
                    centroid    = centroid_new;
                else
                    tryimprove = 0;
                end  
            end
            
            Z{i_seed}           = z;
            Clustpts{i_seed}    = clustpts;
            Clustidcs{i_seed}   = clustidcs;
            Centroid{i_seed}    = centroid;
            
            LLR_z(i_seed)       = llr_z;       
        end
        
        [bestLLR_z, bestseed_idx]          = max(LLR_z);
        
        STIM{subjidx}.centroidadd.LLR_z(i_trial,1)    = bestLLR_z;
        STIM{subjidx}.centroidadd.centroid(i_trial,:) = Centroid{bestseed_idx};
        STIM{subjidx}.centroidadd.z{i_trial}          = Z{bestseed_idx};
    end
end

save('alldata.mat', 'DATA', 'STIM');