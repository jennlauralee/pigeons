%% Append maximum marginal likelihood & posterior mu

%clear
%clc

function [mu_like, mu_post] = get_mufrompaff_maxmargmu(x,y,p_aff)

init = [0,0];
lb   = [-10, -10];
ub   = [10,10];
plb  = [-10,-10];
pub  = [10,10];

n = length(x);

mu_like = bads(@(mu) get_marginal_likelihood_mu(mu,x,y,p_aff), init, lb, ub, plb, pub);
mu_post = bads(@(mu) get_marginal_posterior_mu(mu,x,y,p_aff), init, lb, ub, plb, pub);

end
