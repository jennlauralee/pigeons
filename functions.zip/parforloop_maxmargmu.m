%% parforloop_maxmargmu

parpool(10);
    
parfor subjidx = 1:10
    calc_append_maxmargmu(subjidx);
end
