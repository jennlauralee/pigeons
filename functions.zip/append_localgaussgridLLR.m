%% Append localgaussgrid LLRs to STIM

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')
load('simulated_data.mat')

ns = [6, 9, 12, 15];

for subjidx = 1:length(STIM)
    subjidx
    for i_n = 1:length(ns)
        filt_n = find(STIM{subjidx}.N == ns(i_n));
        
        local_LLR  = STIM{subjidx}.localgaussgrid.LLR(filt_n)';
        isLower = local_LLR < simstim{i_n}.localgaussgrid.LLR.quant;
        [~, highbindx] = max( isLower ~=0, [], 2 );
        quantindx = highbindx-1;
        STIM{subjidx}.simLLR.localgaussgrid(filt_n) = simstim{i_n}.localgaussgrid.LLR.LLR(quantindx);
    end
end

save('alldata.mat', 'DATA', 'STIM');