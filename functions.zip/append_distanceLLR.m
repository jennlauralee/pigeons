%% Append distance LLRs to STIM

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')
load('simulated_data.mat')

ns = [6, 9, 12, 15];

for subjidx = 1:length(STIM)
    subjidx
    for i_n = 1:length(ns)
        filt_n = find(STIM{subjidx}.N == ns(i_n));
        
        MeanDist  = STIM{subjidx}.MeanDist(filt_n);
        isLower = MeanDist < simstim{i_n}.MeanDist.quant;
        [~, highbindx] = max( isLower ~=0, [], 2 );
        quantindx = highbindx-1;
        STIM{subjidx}.simLLR.MeanDist(filt_n) = simstim{i_n}.MeanDist.LLR(quantindx);
        
        MinDist  = STIM{subjidx}.MinDist(filt_n);
        isLower = MinDist < simstim{i_n}.MinDist.quant;
        [~, highbindx] = max( isLower ~=0, [], 2 );
        quantindx = highbindx-1;
        STIM{subjidx}.simLLR.MinDist(filt_n) = simstim{i_n}.MinDist.LLR(quantindx);
        
        meanNNdist  = STIM{subjidx}.meanNNdist(filt_n);
        isLower = meanNNdist < simstim{i_n}.meanNNdist.quant;
        [~, highbindx] = max( isLower ~=0, [], 2 );
        quantindx = highbindx-1;
        STIM{subjidx}.simLLR.meanNNdist(filt_n) = simstim{i_n}.meanNNdist.LLR(quantindx);
    end
end

save('alldata.mat', 'DATA', 'STIM');