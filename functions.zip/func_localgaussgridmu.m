%%

function [LLR_mu, mu] = func_localgaussgridmu(x,y,p_aff)

% gridsearch parameters
sigma_s  = 2;
R      = 10;
thetas = linspace(0,2*pi,90);
rs     = linspace(0,R,20);

n       = length(x);
        
for i_theta = 1:length(thetas)
    for i_r = 1:length(rs)
        r       = rs(i_r);
        theta   = thetas(i_theta);

        grid(i_theta, i_r) = sum(normpdf(x,r*cos(theta),sigma_s)) .* sum(normpdf(y,r*sin(theta),sigma_s));
    end
end

maxval = max(max(grid));
[idx_theta, idx_r] = find(grid == maxval);
mu.theta         = thetas(idx_theta(1));
mu.r             = rs(idx_r(1));
mu.x             = mu.r*cos(mu.theta);
mu.y             = mu.r*sin(mu.theta);

% Calculate the log likelihood ratio
LLR_mu = get_LLR_mu_false_affiliation(x,y,[mu.x mu.y],p_aff);
mu = [mu.x mu.y];

end