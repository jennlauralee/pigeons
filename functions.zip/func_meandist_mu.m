function [LLR_mu, mu] = func_meandist_mu(x,y,p_aff)

mu = [mean(x) mean(y)];
LLR_mu = get_LLR_mu_false_affiliation(x,y,mu,p_aff);

end