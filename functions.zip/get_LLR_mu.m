%% get_LLR_mu

function LLR = get_LLR_mu(x,y,mu)

R       = 10;
sigma_s = 2;
p_b     = 0.5;

n = length(x);

% Get p(x, y | H0)
pxy_H0 = (1/pi/R^2)^n;

% Get p(x, y | H1)
pxy_H1 = prod(p_b.*normpdf(x, mu(1), sigma_s) .* normpdf(y, mu(2), sigma_s) + (1-p_b).*(1/pi/R^2));

LLR = log(pxy_H1 / pxy_H0);

end