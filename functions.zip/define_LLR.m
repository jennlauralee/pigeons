function LLR_type = define_LLR(modelidx)
    switch modelidx
        case 1
            LLR_type = 'bayesd';
        case 29
            LLR_type = 'localgaussgrid.LLR';
        case 30
            LLR_type = 'MeanDist_Mu.LLR_mu';
        case 27
            LLR_type = 'maxmargmu.likelihood.LLR';
        case 28
            LLR_type = 'maxmargmu.posterior.LLR';
        case 17
            LLR_type = 'centroidadd.LLR_z';
        case 26
            LLR_type = 'mostlikelyz.LLR';
        case 34
            LLR_type = 'localgaussgrid.LLR_z_mu';
        case 35
            LLR_type = 'MeanDist_Mu.LLR_z_mu';
        case 32
            LLR_type = 'maxmargmu.likelihood.LLR_z_mu';
        case 33
            LLR_type = 'maxmargmu.posterior.LLR_z_mu';
        case 18
            LLR_type = 'centroidadd_z_mu.LLR_z_mu';
        case 37
            LLR_type = 'brutemax.likelihood.LLR_z_mu';
        case 38
            LLR_type = 'brutemax.posterior.LLR_z_mu';
    end
end
            