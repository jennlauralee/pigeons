function meandist = getMeanDist(Stim)
    for i_trial = 1:length(Stim.X)
        x = Stim.X{i_trial}';
        y = Stim.Y{i_trial}';
        meandist(i_trial,1) = mean(pdist([x y]));
    end
end