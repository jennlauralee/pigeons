%% get N_C0 slope

function NC0_slope = get_NC0_slope(N_C0)
load('alldata.mat')

Ns = [6, 9, 12, 15];

  for subjidx = 1:size(N_C0,1)
      N       = STIM{subjidx}.N;
      C0      = ~STIM{subjidx}.Feeder;
      resp    = categorical(DATA{subjidx}.Resp_feeder,[1,0]);
      
      NC0_slope(subjidx,:) = mnrfit(N(C0), resp(C0))';
  end

  NC0_slope = NC0_slope(:,2);
end