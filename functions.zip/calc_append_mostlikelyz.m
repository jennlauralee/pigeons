%% calc_append_mostlikelyz

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    subjidx
    tic
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        n = length(x); 
        
        poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors 
        nZ          = length(poss_z);
        llrz        = nan(1, nZ);
        maxllr      = [];
        maxidx      = [];
        maxz        = [];
        
        for i_z = 1:nZ
            z = poss_z(i_z,:);
            llrz(i_z) = get_LLR_z(x,y,z);
        end
        
        [maxllr, maxidx] = max(llrz);
        maxz = poss_z(maxidx,:);
            
        STIM{subjidx}.mostlikelyz.maxz{i_trial} = maxz;
        STIM{subjidx}.mostlikelyz.LLR(i_trial)  = maxllr;
    end
    toc
end

save('alldata.mat', 'DATA', 'STIM');