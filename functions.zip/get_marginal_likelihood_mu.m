%% max marginal likelihood of mu

function nl_likelihood = get_marginal_likelihood_mu(mu,x,y,p_aff)

R       = 10;
sigma_s = 2;

if nargin == 3
    p_aff = 0.5;
end

nl_likelihood = -sum(log((1-p_aff)/(pi*R^2) + p_aff.*(normpdf(x, mu(1), sigma_s).*normpdf(y, mu(2), sigma_s))));

end