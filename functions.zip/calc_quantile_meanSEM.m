function Var = calc_quantile_meanSEM(var)

Ns = [6,9,12,15];

for i_N = 1:length(Ns)

    nsubj = length(var);

    for subjidx = 1:nsubj
        Var{i_N}.Nhist(subjidx,:) = var{subjidx}.Nhist{i_N};
        Var{i_N}.Nhist_C1(subjidx,:) = var{subjidx}.Nhist_C1{i_N};
        Var{i_N}.Nhist_C0(subjidx,:) = var{subjidx}.Nhist_C0{i_N};
        Var{i_N}.histcenters(subjidx,:) = var{subjidx}.histcenters{i_N};

        Var{i_N}.quant_midpts(subjidx,:) = var{subjidx}.quant_midpts{i_N};
        Var{i_N}.quant_midpts_C1(subjidx,:) = var{subjidx}.quant_midpts_C1{i_N};
        Var{i_N}.quant_midpts_C0(subjidx,:) = var{subjidx}.quant_midpts_C0{i_N};

        Var{i_N}.pRespFeeder(subjidx,:) = var{subjidx}.pRespFeeder{i_N};
        Var{i_N}.pRespFeeder_C1(subjidx,:) = var{subjidx}.pRespFeeder_C1{i_N};
        Var{i_N}.pRespFeeder_C0(subjidx,:) = var{subjidx}.pRespFeeder_C0{i_N};
        
        Var{i_N}.bin{subjidx} = var{subjidx}.bin{i_N};
        Var{i_N}.bin_C1{subjidx} = var{subjidx}.bin_C1{i_N};        
        Var{i_N}.bin_C0{subjidx} = var{subjidx}.bin_C0{i_N};

%         Var{i_N}.respconf(subjidx,:) = var{subjidx}.respconf{i_N};
%         Var{i_N}.respconf_C1(subjidx,:) = var{subjidx}.respconf_C1{i_N};
%         Var{i_N}.respconf_C0(subjidx,:) = var{subjidx}.respconf_C0{i_N};
    end

    Var{i_N}.Nhist_mean     = mean(Var{i_N}.Nhist);
    Var{i_N}.Nhist_SEM      = std(Var{i_N}.Nhist)./sqrt(nsubj);
    Var{i_N}.Nhist_C1_mean  = mean(Var{i_N}.Nhist_C1);
    Var{i_N}.Nhist_C1_SEM   = std(Var{i_N}.Nhist_C1)./sqrt(nsubj);
    Var{i_N}.Nhist_C0_mean  = mean(Var{i_N}.Nhist_C0);
    Var{i_N}.Nhist_C0_SEM   = std(Var{i_N}.Nhist_C0)./sqrt(nsubj);

    Var{i_N}.quant_midpts_mean      = mean(Var{i_N}.quant_midpts);
    Var{i_N}.quant_midpts_SEM       = std(Var{i_N}.quant_midpts)./sqrt(nsubj);
    Var{i_N}.quant_midpts_C1_mean   = mean(Var{i_N}.quant_midpts_C1);
    Var{i_N}.quant_midpts_C1_SEM    = std(Var{i_N}.quant_midpts_C1)./sqrt(nsubj);
    Var{i_N}.quant_midpts_C0_mean   = mean(Var{i_N}.quant_midpts_C0);
    Var{i_N}.quant_midpts_C0_SEM    = std(Var{i_N}.quant_midpts_C0)./sqrt(nsubj);

    Var{i_N}.pRespFeeder_mean       = mean(Var{i_N}.pRespFeeder);
    Var{i_N}.pRespFeeder_SEM        = std(Var{i_N}.pRespFeeder)./sqrt(nsubj);
    Var{i_N}.pRespFeeder_C1_mean    = mean(Var{i_N}.pRespFeeder_C1);
    Var{i_N}.pRespFeeder_C1_SEM     = std(Var{i_N}.pRespFeeder_C1)./sqrt(nsubj);
    Var{i_N}.pRespFeeder_C0_mean    = mean(Var{i_N}.pRespFeeder_C0);
    Var{i_N}.pRespFeeder_C0_SEM     = std(Var{i_N}.pRespFeeder_C0)./sqrt(nsubj);

%     Var{i_N}.respconf_mean          = mean(Var{i_N}.respconf);
%     Var{i_N}.respconf_SEM           = std(Var{i_N}.respconf)./sqrt(nsubj);
%     Var{i_N}.respconf_C1_mean       = mean(Var{i_N}.respconf_C1);
%     Var{i_N}.respconf_C1_SEM        = std(Var{i_N}.respconf_C1)./sqrt(nsubj);
%     Var{i_N}.respconf_C0_mean       = mean(Var{i_N}.respconf_C0);
%     Var{i_N}.respconf_C0_SEM        = std(Var{i_N}.respconf_C0)./sqrt(nsubj);
end

end