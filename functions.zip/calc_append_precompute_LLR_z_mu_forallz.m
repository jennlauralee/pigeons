%% calc_append_precompute_LLR_z_mu_forallz
clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    precomputed_LLR_forallz = [];
    tic
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        [precomputed_LLR_forallz.like{subjidx}{i_trial},...
         precomputed_LLR_forallz.post{subjidx}{i_trial}] = precompute_LLR_z_mu_forallz(x,y);
    end  
    toc
    num2str(subjidx)
    
    save(['precomputed_LLR_forallz_S' num2str(subjidx) '.mat'], 'precomputed_LLR_forallz');
end