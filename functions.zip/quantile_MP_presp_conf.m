function var = quantile_MP_presp_conf(Summtype, Modelresults, modelidx, STIM) 
Ns = [6 9 12 15];
load('allsummstats.mat');

nsubj = length(Modelresults{modelidx}.NLL);

for i_N = 1:length(Ns)
     for subjidx = 1:nsubj
        
        filt_N = STIM{subjidx}.N == Ns(i_N);
        feeder = STIM{subjidx}.Feeder;
         
        modelpred = Modelresults{modelidx}.modelpred(subjidx,:);
        modelpred_N = modelpred(filt_N);
        modelpred_N_C1 = modelpred(filt_N & feeder);
        modelpred_N_C0 = modelpred(filt_N & ~feeder);
    
        bin    = Summtype{i_N}.bin{subjidx};
        bin_C0 = Summtype{i_N}.bin_C0{subjidx};
        bin_C1 = Summtype{i_N}.bin_C1{subjidx};
        
        for i_bin = 1:size(bin,2)
            pRespFeeder(i_bin) = mean(modelpred_N(bin(:,i_bin)));
            pRespFeeder_C1(i_bin) = mean(modelpred_N_C1(bin_C1(:,i_bin)));
            pRespFeeder_C0(i_bin) = mean(modelpred_N_C0(bin_C0(:,i_bin)));
        end

        var{i_N}.pRespFeeder(subjidx,:)    = pRespFeeder;
        var{i_N}.pRespFeeder_C1(subjidx,:) = pRespFeeder_C1;
        var{i_N}.pRespFeeder_C0(subjidx,:) = pRespFeeder_C0;
     end
     
    var{i_N}.pRespFeeder_mean       = mean(var{i_N}.pRespFeeder);
    var{i_N}.pRespFeeder_SEM        = std(var{i_N}.pRespFeeder)./sqrt(nsubj);
    var{i_N}.pRespFeeder_C1_mean    = mean(var{i_N}.pRespFeeder_C1);
    var{i_N}.pRespFeeder_C1_SEM     = std(var{i_N}.pRespFeeder_C1)./sqrt(nsubj);
    var{i_N}.pRespFeeder_C0_mean    = mean(var{i_N}.pRespFeeder_C0);
    var{i_N}.pRespFeeder_C0_SEM     = std(var{i_N}.pRespFeeder_C0)./sqrt(nsubj);
end
end