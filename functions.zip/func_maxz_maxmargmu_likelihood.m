%% func_maxz_maxmargmu_likelihood

function [LLR_z_mu] = func_maxz_maxmargmu_likelihood(x,y,p_aff)

[~, mu_like] = func_maxmargmu_like(x,y,p_aff); %make this a look-up table with interp1
LLR_z_mu = func_maxz(x,y,mu_like,p_aff);
end