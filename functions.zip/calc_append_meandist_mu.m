%% Append the average x and y coordinate as mean dist mu estimate, calc C1_likelihoods

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

sigma_s     = 2;

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        
        mu = [mean(x) mean(y)];
        
        STIM{subjidx}.MeanDist_Mu.trial(i_trial,:) = mu;
        STIM{subjidx}.MeanDist_Mu.LLR_mu(i_trial,:) = get_LLR_mu(x,y,mu);
        STIM{subjidx}.MeanDist_Mu.C1_likelihoods{i_trial}(:,1) = normpdf(x,mu(1),sigma_s).*normpdf(y,mu(2),sigma_s);
    end
end

save('alldata.mat', 'DATA', 'STIM');