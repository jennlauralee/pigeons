%% Append the C1_likelihoods based on EM mu

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

sigma_s     = 2;

for subjidx = 1:length(STIM)
    STIM{subjidx}.MeanDist_Mu.C1_likelihoods = [];
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        
        mu = STIM{subjidx}.EM.mu(i_trial,:);
        
        STIM{subjidx}.EM.C1_likelihoods{i_trial}(:,1) = normpdf(x,mu(1),sigma_s).*normpdf(y,mu(2),sigma_s);
    end
end

save('alldata.mat', 'DATA', 'STIM');