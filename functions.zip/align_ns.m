%% align group-level p_RF by subject ns
function RF = align_ns(rf)

ns = [0:15];
Ns    = [6, 9, 12, 15];

nsubj       = length(rf);
        
RF.n1       = nan(nsubj, length(ns));
RF.n0_C0    = nan(nsubj, length(Ns));
RF.n0_C1    = nan(nsubj, length(ns));
RF.n0n1     = nan(nsubj, length(ns), length(ns));
RF.Nn0      = nan(nsubj, length(Ns), length(ns));

RF.Nn0_C1   = nan(nsubj, length(Ns), length(ns));
RF.Nn1_C1   = nan(nsubj, length(Ns), length(ns));

RF.N_C1     = nan(nsubj, length(Ns));
RF.N_C0     = nan(nsubj, length(Ns));

for subjidx = 1:nsubj
    for i_n0 = 1:length(ns)
        n0 = ns(i_n0);
        n0_idx = find(rf{subjidx}.n0s == n0);
        
        if length(n0_idx) > 0
            RF.n0_C1(subjidx,i_n0) = rf{subjidx}.n0_C1(n0_idx);
        end
        
        if sum(n0 == Ns)
            n0C0_idx = find(n0 == Ns);
            RF.n0_C0(subjidx,n0C0_idx) = rf{subjidx}.n0_C0(n0C0_idx);
        end

        for i_n1 = 1:length(ns)
            n1 = ns(i_n1);
            n1_idx = find(rf{subjidx}.n1s == n1);

            if length(n1_idx) > 0
                RF.n1(subjidx,i_n1) = rf{subjidx}.n1(n1_idx);
            end
            
            if length(n0_idx)>0 & length(n1_idx)>0
                RF.n0n1(subjidx, i_n0, i_n1) = rf{subjidx}.n0n1(n0_idx,n1_idx);
            end
        end
    end
end


for subjidx = 1:nsubj
    for i_N = 1:length(Ns)
    N = Ns(i_N);
    N_idx = find(rf{subjidx}.Ns == N);
    
    RF.N_C1(subjidx, i_N) = rf{subjidx}.N_C1(N_idx);
    RF.N_C0(subjidx, i_N) = rf{subjidx}.N_C0(N_idx);
    
        for i_n0 = 1:length(ns)
            n0 = ns(i_n0);
            n0_idx = find(rf{subjidx}.n0s == n0);
            if length(n0_idx)>0
                RF.Nn0_C1(subjidx, i_N, i_n0) = rf{subjidx}.Nn0_C1(N_idx,n0_idx);
            end
        end
        
        for i_n1 = 1:length(ns)
            n1 = ns(i_n1);
            n1_idx = find(rf{subjidx}.n1s == n1);
            if length(n1_idx)>0
                RF.Nn1_C1(subjidx, i_N, i_n1) = rf{subjidx}.Nn1_C1(N_idx,n1_idx);
            end
        end
        
    end
end

RF.N_C1_mean = nanmean(RF.N_C1);
RF.N_C1_SEM = nanstd(RF.N_C1)./sqrt(sum(~isnan(RF.N_C1)));

RF.N_C0_mean = nanmean(RF.N_C0);
RF.N_C0_SEM = nanstd(RF.N_C0)./sqrt(sum(~isnan(RF.N_C0)));

RF.n1_mean  = nanmean(RF.n1);
RF.n1_SEM   = nanstd(RF.n1)./sqrt(sum(~isnan(RF.n1)));

RF.n0_C1_mean    = nanmean(RF.n0_C1);
RF.n0_C1_SEM     = nanstd(RF.n0_C1)./sqrt(sum(~isnan(RF.n0_C1)));

RF.n0_C0_mean    = nanmean(RF.n0_C0);
RF.n0_C0_SEM     = nanstd(RF.n0_C0)./sqrt(sum(~isnan(RF.n0_C0)));

RF.n0n1_mean     = squeeze(nanmean(RF.n0n1));
RF.n0n1_SEM      = squeeze(nanstd(RF.n0n1)./sqrt(sum(~isnan(RF.n0n1))));

RF.Nn0_C1_mean     = squeeze(nanmean(RF.Nn0_C1));
RF.Nn0_C1_SEM      = squeeze(nanstd(RF.Nn0_C1)./sqrt(sum(~isnan(RF.Nn0_C1))));

RF.Nn1_C1_mean     = squeeze(nanmean(RF.Nn1_C1));
RF.Nn1_C1_SEM      = squeeze(nanstd(RF.Nn1_C1)./sqrt(sum(~isnan(RF.Nn1_C1))));
end
