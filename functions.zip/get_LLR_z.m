function LLR_z = get_LLR_z(x,y,z)
% This is actually the marginal likelihood of z
% calculate LLR based on given [x,y] observations and z membership vector

% Parameter assumptions
        
sig_s       = 2; % how far from center does the feeder spawn?
sig         = 2; % how far from feeder do pigeons spawn?
R           = 10;

n = length(x);

% Evaluate pxy_H0
pxy_H0   = (1/pi/R^2)^n;

% Evaluate single-member pxy_H1
i_1 = find(z);
n1 = sum(z); %Number of hypothesized affiliated pigeons
n0 = n - n1; %Number of hypothesized unaffiliated pigeons

expo_x = -(1/(2*sig^2))*  (sum(x(i_1).^2) - (sum(x(i_1)).^2 * sig_s^2)/(sig_s^2*n1 + sig^2));
expo_y = -(1/(2*sig^2))*  (sum(y(i_1).^2) - (sum(y(i_1)).^2 * sig_s^2)/(sig_s^2*n1 + sig^2));
pxy_H1_z = (1/pi/R^2)^n0 * (1/(2*pi*sig^2))^n1 * sig^2/(n1*sig_s^2 + sig^2) * exp(expo_x + expo_y);

LLR_z = log(pxy_H1_z./pxy_H0);