%% Append maximum marginal likelihood & posterior mu

%clear
%clc

%addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));

function calc_append_maxmargmu(subjidx)

load('alldata.mat')

addpath(genpath('bads-master'));

init = [0,0];
lb   = [-10, -10];
ub   = [10,10];
plb  = [-10,-10];
pub  = [10,10];

%for subjidx = 1:length(STIM)
for i_trial = 1:length(STIM{subjidx}.X)
    x = STIM{subjidx}.X{i_trial}';
    y = STIM{subjidx}.Y{i_trial}';
    n = length(x);

    for run = 1 %%%%% CHANGE GET_MARGINAL_LIKELIHOOD_MU and GET_MARGINAL_POSTERIOR_MU to have false p_aff
        [mu_like_run(run,:), NLL_like_run(run)] = bads(@(mu) get_marginal_likelihood_mu(mu,x,y), init, lb, ub, plb, pub);
        [mu_post_run(run,:), NLL_post_run(run)] = bads(@(mu) get_marginal_posterior_mu(mu,x,y), init, lb, ub, plb, pub);
    end

    NLL_like_run
    NLL_post_run

    [~, runidx_like] = min(NLL_like_run);
    [~, runidx_post] = min(NLL_post_run);

    mu_like = mu_like_run(runidx_like,:);
    mu_post = mu_post_run(runidx_post,:);

    LLR_mu_like = get_LLR_mu(x,y,mu_like);
    LLR_mu_post = get_LLR_mu(x,y,mu_post);

    maxmargmu.likelihood.mu(i_trial,:) = mu_like;
    maxmargmu.likelihood.LLR(i_trial,:) = LLR_mu_like;
    maxmargmu.posterior.mu(i_trial,:) = mu_post;
    maxmargmu.posterior.LLR(i_trial,:) = LLR_mu_post;        
end

save(['S' num2str(subjidx) '_maxmargmu.mat'], 'maxmargmu');
end


%% append
% clear
% clc
% 
% load('alldata.mat')
% 
% for subjidx = 1:10
%     load(['S' num2str(subjidx) '_maxmargmu.mat']);
%     STIM{subjidx}.maxmargmu = maxmargmu;
% end
% 
% save('alldata.mat', 'DATA', 'STIM');