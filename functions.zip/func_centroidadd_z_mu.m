%% Append centroid-add-one algorithm, z and mu-conditioned

%% 1. Start with each point; add the nearest point to the centroid
% until doing so doesn't increase the log likelihood ratio anymore

%% 2. Compare across all N starting points to see which yielded best LLR_z_mu

%% 3. Fit threshold on LLR_z_mu

function [bestLLR_z_mu, best_centroid, best_z] = func_centroidadd_z_mu(x, y, p_aff)

pigs = [x y];
n = length(x);

LLR_z_mu    = [];
z           = [];
clustpts    = [];
clustidcs   = [];
centroid    = [];

for i_seed = 1:n

    % Initialize first cluster (single point)
    z              = zeros(1,n);
    z(i_seed)      = 1;
    clustpts       = pigs(i_seed,:);
    clustidcs      = i_seed;
    centroid       = clustpts;

    llr_z_mu       = get_LLR_z_mu_false_affiliation(x,y,z,centroid,p_aff);

    tryimprove = 1;

    while tryimprove
        % Find next nearest point to current cluster
        pigs_ = pigs;
        pigs_([clustidcs],:) = inf; % Set previously clustered points to inf
        [~, NNindx] = min(pdist2(centroid,pigs_));

        % Try adding NN to form new cluster
        z_new           = z;
        z_new(NNindx)   = 1;
        clustpts_new    = [clustpts; pigs(NNindx,:)];
        clustidcs_new   = [clustidcs; NNindx];
        centroid_new    = mean(clustpts,1);

        % Get new LLR
        llr_z_mu_new   = get_LLR_z_mu_false_affiliation(x,y,z_new,centroid_new,p_aff);

        if llr_z_mu_new > llr_z_mu
            tryimprove  = 1;

            llr_z_mu       = llr_z_mu_new;
            z           = z_new;
            clustpts    = clustpts_new;
            clustidcs   = clustidcs_new;
            centroid    = centroid_new;
        else
            tryimprove = 0;
        end
    end

    Z{i_seed}           = z;
    Clustpts{i_seed}    = clustpts;
    Clustidcs{i_seed}   = clustidcs;
    Centroid{i_seed}    = centroid;

    LLR_z_mu(i_seed)     = llr_z_mu;       
end

[bestLLR_z_mu, bestseed_idx]          = max(LLR_z_mu);

best_centroid = Centroid{bestseed_idx};
best_z = Z{bestseed_idx};

end
