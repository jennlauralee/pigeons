%% Append maximum marginal likelihood & posterior mu

%clear
%clc

%addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));

function [LLR_mu_post, mu_post] = func_maxmargmu_post(x,y,p_aff)

init = [0,0];
lb   = [-10, -10];
ub   = [10,10];
plb  = [-10,-10];
pub  = [10,10];

n = length(x);

mu_post = bads(@(mu) get_marginal_posterior_mu(mu,x,y,p_aff), init, lb, ub, plb, pub);

LLR_mu_post = get_LLR_mu_false_affiliation(x,y,mu_post,p_aff);

end


%% append
% clear
% clc
% 
% load('alldata.mat')
% 
% for subjidx = 1:10
%     load(['S' num2str(subjidx) '_maxmargmu.mat']);
%     STIM{subjidx}.maxmargmu = maxmargmu;
% end
% 
% save('alldata.mat', 'DATA', 'STIM');