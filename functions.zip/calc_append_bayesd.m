%% Append bayesian_d calculation to STIM
clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    subjidx
    tic;
    STIM{subjidx}.bayesd = get_bayesian_d(STIM{subjidx}.X, STIM{subjidx}.Y);
    toc
end

%save('alldata.mat', 'DATA', 'STIM');
