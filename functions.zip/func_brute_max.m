%% brute force maximization

function [LLR_z_mu_like, LLR_z_mu_post] = func_brute_max(x,y,p_aff)

sig_s       = 2; % how far from center does the feeder spawn?
sig         = 2; % how far from feeder do pigeons spawn?

n = length(x);

poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors
nZ          = length(poss_z);
%%%%%%%%%%%%%%% ADD; p(z) is p_aff^n1 * (1-p_aff)^n0
mu_like_  = nan(length(poss_z),2);
mu_post_  = nan(length(poss_z),2);
LLR_like_ = nan(length(poss_z),1);
LLR_post_ = nan(length(poss_z),1);

for i_z = 1:length(poss_z)
    z_ = poss_z(i_z,:);
    i_1 = find(z_);
    n1 = sum(z_); %Number of hypothesized affiliated pigeons
    n0 = n - n1; %Number of hypothesized unaffiliated pigeons

    mu_like_(i_z,:) = [mean(x(i_1)) mean(y(i_1))];
    mu_post_(i_z,:) = [sum(x(i_1))/sig^2 / (1/sig_s^2 + n1/sig^2)  ,  sum(y(i_1))/sig^2 / (1/sig_s^2 + n1/sig^2)];

    get_LLR_z_mu_false_affiliation(x,y,z_,mu_like_(i_z,:), p_aff);
    get_LLR_z_mu_false_affiliation(x,y,z_,mu_post_(i_z,:), p_aff);
end

[LLR_z_mu_like] = max(LLR_like_);
[LLR_z_mu_post] = max(LLR_post_);

end
    
