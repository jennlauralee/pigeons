% rerun cluster output processing
clear
clc

paffmodel = 1;

for i = 2
    modelidx = i;
    
    if paffmodel
        pafftext = '_paff';
        filepath = '/Users/jennlauralee/GitHub Repos/pigeons/Analysis/results/raw_cluster_output_paff';
    else
        pafftext = '';
        filepath = '/Users/jennlauralee/GitHub Repos/pigeons/Analysis/results/raw_cluster_output';
    end
    
    process_cluster_output(filepath, modelidx, paffmodel);
    
    path_results = '/Users/jennlauralee/GitHub Repos/pigeons/Analysis/results/'
    
    load([path_results 'results_' num2str(modelidx) pafftext '.mat'])
    
    nlls_ = round(Modelresults{i}.NLLs);
    NLLdiffs = nlls_ - min(nlls_,[],2);
    
    print(NLLdiffs);
end