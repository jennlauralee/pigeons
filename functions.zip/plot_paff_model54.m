%% analyze p_aff
clear
clc
close all

load('results_54');

figd;

ns = [6, 9, 12, 15];
nsubs = length(Modelresults{54}.NLL);

plot(ns, Modelresults{54}.par_est(:,4:7), 'o-');


figd;
plot(ns, mean(Modelresults{54}.par_est(:,4:7))); hold on
errorbar(ns, mean(Modelresults{54}.par_est(:,4:7)), std(Modelresults{54}.par_est(:,4:7))./sqrt(nsubs), 'LineWidth', 2, 'Color', 'r'); hold on
xlabel('N')
ylabel('p_a_f_f')
xlim([6 15])
xticks(ns)