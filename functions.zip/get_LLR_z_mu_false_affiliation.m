function LLR_z_mu = get_LLR_z_mu_false_affiliation(x,y,z,mu,p_aff)
% calculate the LLR for a fixed z and fixed mu. mu given [x,y].

sigma_s = 2;
R       = 10;

n = length(x);

% Get p(x, y | H0)
pxy_H0 = (1/pi/R^2)^n;

% Get p(x, y | H1)
i_1 = find(z); %Indices of affiliated pigeons
n1 = sum(z); %Number of hypothesized affiliated pigeons
n0 = n - n1; %Number of hypothesized unaffiliated pigeons

pxy_H1 = prod(p_aff.*normpdf(x(i_1), mu(1), sigma_s) .* normpdf(y(i_1), mu(2), sigma_s)) .*...
    ((1-p_aff)/pi/R^2)^n0;

% Calculate the log likelihood ratio
LLR_z_mu = log(pxy_H1 / pxy_H0);