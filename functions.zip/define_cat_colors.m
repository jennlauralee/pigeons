% define category colors

function colors = define_cat_colors
colors.A     = [102,194,165]./255;
colors.B     = [252,141,98]./255;
colors.C     = [141,160,203]./255;
colors.D     = [231,138,195]./255;
colors.H     = [166,216,84]./255;
end