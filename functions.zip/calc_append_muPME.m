%% calc_append_muPME

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    subjidx
    stim = STIM{subjidx};
    tic
    for i_trial = 1:length(stim.X)
        x = stim.X{i_trial};
        y = stim.Y{i_trial};
        [STIM{subjidx}.PME_mu.LLR_mu(i_trial), STIM{subjidx}.PME_mu.mu(i_trial,:)] = func_mu_PME(x, y, 0.5);
    end
    toc
end

save('alldata.mat', 'DATA', 'STIM');