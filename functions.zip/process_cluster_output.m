%% process cluster output of model fit
function process_cluster_output(filepath, modelidx, paffmodel)

cd(filepath)
listfiles = dir(['*results_' num2str(modelidx) '*.mat']);

nlist = length(listfiles);
nsubj = 10;
nruns = 100;

NLLs = nan(10,nruns);

for ii = 1:nlist
    load(listfiles(ii).name);
    [sub, run] = find(~cellfun(@isempty,modelresults));
    concat{sub,run} = modelresults{sub,run};
    NLLs(sub,run) = modelresults{sub,run}.NLL;
end

minNLLs = min(NLLs');
for i_sub = 1:nsubj
    n_bestruns(i_sub) = sum(NLLs(i_sub,:)==minNLLs(i_sub));
    bestrun = find(NLLs(i_sub,:)==minNLLs(i_sub),1);
    Modelresults_{i_sub} = concat{i_sub,bestrun};
end

%% save in general superstructure
for subjidx = 1:nsubj
    Modelresults{modelidx}.par_est(subjidx,:)   = Modelresults_{subjidx}.par_est;
    Modelresults{modelidx}.NLL(subjidx,:)       = Modelresults_{subjidx}.NLL;
    Modelresults{modelidx}.modelpred(subjidx,:) = Modelresults_{subjidx}.modelpred;
    Modelresults{modelidx}.NLLs                 = NLLs;
end

if paffmodel
    pafftext = '_paff';
else
    pafftext = '';
end

path_results = '/Users/jennlauralee/GitHub Repos/pigeons/Analysis/results/';
save([path_results 'results_' num2str(modelidx) pafftext '.mat'],'Modelresults')
end

% find NLLs
% sprintf('%.0f,' , miss_ind)

% [submiss,runmiss] = find(isnan(NLLs))
% subvec = [1:nsubj];
% runvec = [1:nruns];
% paffvec = [1];
% 
% designmat = combvec(subvec,runvec,paffvec)';
% designmat_ = designmat(:,1:2);
% missing = [submiss runmiss]
% [~,miss_ind] = ismember(missing,designmat_, 'rows')

