%% Append mean nearest-neighbour pairwise distance

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        n = length(x);
        d = pdist2([x y], [x y]);
        d = reshape(d(d>0),n-1,n);
        
        STIM{subjidx}.meanNNdist(i_trial,1) = mean(min(d));
        STIM{subjidx}.NNdist{i_trial} = min(d);
    end
end

save('alldata.mat', 'DATA', 'STIM');