function var = quantile_presp_conf(stimtype, quantiles, histedges, STIM, DATA, subjidx)

Ns = [6,9,12,15];

for i_N = 1:length(Ns)
    
    filt_N = STIM{subjidx}.N == Ns(i_N);
        
    feeder      = STIM{subjidx}.Feeder;
    resp_feeder = DATA{subjidx}.Resp_feeder;
    
    quant = prctile(stimtype(filt_N), quantiles);
    quant_midpts = mean([quant(2:end); quant(1:end-1)]);

    quant_C1 = prctile(stimtype(filt_N & feeder), quantiles);
    quant_midpts_C1 = mean([quant_C1(2:end); quant_C1(1:end-1)]);

    quant_C0 = prctile(stimtype(filt_N & ~feeder), quantiles);
    quant_midpts_C0 = mean([quant_C0(2:end); quant_C0(1:end-1)]);

    for i_quantile = 1:length(quant)-1
        if i_quantile == length(quant)-1 % last quantile includes final entry
                bin(:,i_quantile) = stimtype(filt_N)>=quant(i_quantile) & stimtype(filt_N) <=quant(i_quantile+1);
                bin_C1(:,i_quantile) = stimtype(filt_N & feeder)>=quant_C1(i_quantile) & stimtype(filt_N & feeder) <=quant_C1(i_quantile+1);
                bin_C0(:,i_quantile) = stimtype(filt_N & ~feeder)>=quant_C0(i_quantile) & stimtype(filt_N & ~feeder) <=quant_C0(i_quantile+1);
        else 
            bin(:,i_quantile) = stimtype(filt_N)>=quant(i_quantile) & stimtype(filt_N) <quant(i_quantile+1);
            bin_C1(:,i_quantile) = stimtype(filt_N & feeder)>=quant_C1(i_quantile) & stimtype(filt_N & feeder) <quant_C1(i_quantile+1);
            bin_C0(:,i_quantile) = stimtype(filt_N & ~feeder)>=quant_C0(i_quantile) & stimtype(filt_N & ~feeder) <quant_C0(i_quantile+1);
        end
    end

    for i_bin = 1:size(bin,2)
%         respconf(i_bin) = mean(resp_conf_N(bin(:,i_bin)));
%         respconf_C1(i_bin) = mean(resp_conf_N(bin_C1(:,i_bin) & feeder_N));
%         respconf_C0(i_bin) = mean(resp_conf_N(bin_C0(:,i_bin) & ~feeder_N));
         
        pRespFeeder(i_bin) = sum(resp_feeder(filt_N) & bin(:,i_bin))./sum(bin(:,i_bin));
        pRespFeeder_C1(i_bin) = sum(resp_feeder(filt_N & feeder) & bin_C1(:,i_bin))./sum(bin_C1(:,i_bin));
        pRespFeeder_C0(i_bin) = sum(resp_feeder(filt_N & ~ feeder) & bin_C0(:,i_bin))./sum(bin_C0(:,i_bin));
    end
     
    [Nhist] = histcounts(stimtype(filt_N), histedges);
    [Nhist_C1] = histcounts(stimtype(filt_N & feeder), histedges);
    [Nhist_C0] = histcounts(stimtype(filt_N & ~feeder), histedges);
    
    histcenters = mean([histedges(2:end); histedges(1:end-1)]);
    
    var.quant{i_N} = quant;
    var.quant_midpts{i_N} = quant_midpts;
    var.quant_C1{i_N} = quant_C1;
    var.quant_midpts_C1{i_N} = quant_midpts_C1;
    var.quant_C0{i_N} = quant_C0;
    var.quant_midpts_C0{i_N} = quant_midpts_C0;
    var.bin{i_N} = bin;
    var.bin_C1{i_N} = bin_C1;
    var.bin_C0{i_N} = bin_C0;
    var.pRespFeeder{i_N} = pRespFeeder;
    var.pRespFeeder_C1{i_N} = pRespFeeder_C1;
    var.pRespFeeder_C0{i_N} = pRespFeeder_C0;
    
%     var.respconf{i_N} = respconf;
%     var.respconf_C1{i_N} = respconf_C1;
%     var.respconf_C0{i_N} = respconf_C0;

    var.histedges{i_N} = histedges;
    var.histcenters{i_N} = histcenters;
    
    var.Nhist{i_N} = Nhist;
    var.Nhist_C1{i_N} = Nhist_C1;
    var.Nhist_C0{i_N} = Nhist_C0;
end
end