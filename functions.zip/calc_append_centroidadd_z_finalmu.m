%% Append centroid-add-one algorithm, z with FINAL iteration mu-conditioning

%% 1. Start with each point; add nearest point to the centroid 
% until doing so doesn't increase the LLR_z anymore

%% 2. Compare across all N starting points to see which yielded best LLR_z

%% 3. Use the centroid of the final z-cluster as mu. Calculate a FINAL LLR,
% which is z- AND (final) mu-conditioned.

% Basically, this model uses the LLR_z with marginalization over all mu's
% in order to decide whether to add a new point to the z-vector
% But the final LLR is both z-conditioned and mu-conditioned

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        n = length(x);
        
        z  = STIM{subjidx}.centroidadd.z{i_trial};
        mu = STIM{subjidx}.centroidadd.centroid(i_trial,:);
        
        STIM{subjidx}.centroidadd.LLR_z_finalmu(i_trial,1) = get_LLR_z_mu(x,y,z,mu);
    end
end

save('alldata.mat', 'DATA', 'STIM');