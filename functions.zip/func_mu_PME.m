%% func_mu_PME

function [LLR_muPME, mu_PME] =  func_mu_PME(x,y,p_aff)
n = length(x);
poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors
nZ          = length(poss_z);

sig = 2;
sig_s = 2;
R = 10;

top_ = nan(nZ,2);
bottom_ = nan(nZ,1);

for i_z = 1:nZ 
    z_ = poss_z(i_z,:);
    n1 = sum(z_);
    n0 = n - n1;
    n1idx = find(z_);
    
    %% w_tilda
    denom1 = 1 + n1*(sig^2/sig_s^2);
    denom2 = (2*pi*sig_s^2)^n1;
    xsum = sum(x(n1idx));
    ysum = sum(y(n1idx));
    sqbrackets = sum(x(n1idx).^2 + y(n1idx).^2) - ((xsum.^2 + ysum.^2)./(n1 + sig_s^2/sig^2));
    
    w_tilda = (1/denom1)*(1/denom2) * exp(-1/(2*sig_s^2) *  sqbrackets);
    
    %% w
    pz = p_aff^n1 * (1-p_aff)^n0;
    w = pz/(pi*R^2)^n0;
    
    %% m
    coeffm = 1/(n1 + sig_s^2/sig^2);
    m = coeffm * [xsum ysum];
    
    %% mu_PME
    top_(i_z,:) = w*w_tilda*m;
    bottom_(i_z) = w*w_tilda;
end


mu_PME = sum(top_)./sum(bottom_);
LLR_muPME = get_LLR_mu_false_affiliation(x,y,mu_PME,p_aff);

end