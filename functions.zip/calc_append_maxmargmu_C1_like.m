%% calculate C1 likelihoods (based on max marginal [likelihood/ posterior] mu)

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

sigma_s     = 2;

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        mu_like = STIM{subjidx}.maxmargmu.likelihood.mu(i_trial,:);
        mu_post = STIM{subjidx}.maxmargmu.posterior.mu(i_trial,:);
        
        STIM{subjidx}.maxmargmu.likelihood.C1_likelihoods{i_trial}(:,1) = normpdf(x,mu_like(1),sigma_s).*normpdf(y,mu_like(2),sigma_s);
        STIM{subjidx}.maxmargmu.posterior.C1_likelihoods{i_trial}(:,1) = normpdf(x,mu_post(1),sigma_s).*normpdf(y,mu_post(2),sigma_s);
    end
end

save('alldata.mat', 'DATA', 'STIM');