%% Concatenate false bayes 53
clear
clc

addpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/false bayes 53/')

for subjidx = 1:10
    for runidx = 1:10
        load(['results_53_sub_' num2str(subjidx) '_run_' num2str(runidx) '.mat'],'modelresults');
        
        Modelresults{53}.par_est(subjidx,:)        = modelresults{subjidx,runidx}.par_est;
        Modelresults{53}.NLL(subjidx,:) = modelresults{subjidx,runidx}.NLL;
        Modelresults{53}.modelpred(subjidx,:)      = modelresults{subjidx,runidx}.modelpred;
    end
end

save('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/results/results_53.mat','Modelresults')