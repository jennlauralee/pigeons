%% brute force maximization

% clear
% clc
%
% addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
function calc_append_brute_max(subjidx)

load('alldata.mat')

sig_s       = 2; % how far from center does the feeder spawn?
sig         = 2; % how far from feeder do pigeons spawn?

for i_trial = 1:length(STIM{subjidx}.X)
    tic
    x = STIM{subjidx}.X{i_trial}';
    y = STIM{subjidx}.Y{i_trial}';
    n = length(x);
    
    poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors
    nZ          = length(poss_z);
    %%%%%%%%%%%%%%% ADD; p(z) is p_aff^n1 * (1-p_aff)^n0
    mu_like_  = [];
    mu_post_  = [];
    LLR_like_ = [];
    LLR_post_ = [];
    
    for i_z = 1:length(poss_z)
        z_ = poss_z(i_z,:);
        i_1 = find(z_);
        n1 = sum(z_); %Number of hypothesized affiliated pigeons
        n0 = n - n1; %Number of hypothesized unaffiliated pigeons
        
        mu_like_(i_z,:) = [mean(x(i_1)) mean(y(i_1))];
        mu_post_(i_z,:) = [sum(x(i_1))/sig^2 / (1/sig_s^2 + n1/sig^2)  ,  sum(y(i_1))/sig^2 / (1/sig_s^2 + n1/sig^2)];
        
        LLR_like_(i_z) = get_LLR_z_mu(x,y,z_,mu_like_(i_z,:));
        LLR_post_(i_z) = get_LLR_z_mu(x,y,z_,mu_post_(i_z,:));
    end
    
    if false_aff ==0
        [LLR_like maxidx_like] = max(LLR_like_);
        [LLR_post maxidx_post] = max(LLR_post_);
    else
        [LLR_like maxidx_like] = max(LLR_like_ .* prior_z);%%%%%% CHANGED!!!
        [LLR_post maxidx_post] = max(LLR_post_ .* prior_z); %%%%%%% CHANGED!!!
    end
    
    mu_like = mu_like_(maxidx_like,:);
    mu_post = mu_post_(maxidx_post,:);
    
    z_like  = poss_z(maxidx_like,:);
    z_post  = poss_z(maxidx_post,:);
    
    brutemax.likelihood.mu(i_trial,:)       = mu_like;
    brutemax.likelihood.LLR_z_mu(i_trial,:) = LLR_like;
    brutemax.likelihood.z{i_trial}          = z_like;
    
    brutemax.posterior.mu(i_trial,:)        = mu_post;
    brutemax.posterior.LLR_z_mu(i_trial,:)  = LLR_post;
    brutemax.posterior.z{i_trial}           = z_post;
    
    toc
end

save(['S' num2str(subjidx) '_brutemax.mat'], 'brutemax');

end

%% append
clear
clc

load('alldata.mat')

for subjidx = 1:10
    load(['S' num2str(subjidx) '_brutemax.mat']);
    STIM{subjidx}.brutemax = brutemax;
end

save('alldata.mat', 'DATA', 'STIM');