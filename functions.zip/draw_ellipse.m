function draw_ellipse(xs,ys,incolour)

data = [xs' ys'];

sem_x = std(xs')./sqrt(length(xs));
sem_y = std(ys')./sqrt(length(ys));

x1 = mean(xs)-sem_x/2;
x2 = mean(xs)+sem_x/2;
y1 = mean(ys)-sem_y/2;
y2 = mean(ys)+sem_y/2;

% Calculate the eigenvectors and eigenvalues
covariance = cov(data);
[eigenvec, eigenval] = eig(covariance);

% Get the index of the largest eigenvector
[largest_eigenvec_ind_c, r] = find(eigenval == max(max(eigenval)));
largest_eigenvec = eigenvec(:, largest_eigenvec_ind_c);


% Calculate the angle between the x-axis and the largest eigenvector
w = atan2(largest_eigenvec(2), largest_eigenvec(1));

e = 0;

a = 1/2*sqrt((x2-x1)^2+(y2-y1)^2);
b = a*sqrt(1-e^2);
t = linspace(0,2*pi);
X = a*cos(t);
Y = b*sin(t);
x = (x1+x2)/2 + X*cos(w) - Y*sin(w);
y = (y1+y2)/2 + X*sin(w) + Y*cos(w);
F = plot(x,y,incolour); hold on
H = fill(x,y,incolour);

end