%% Append centroid-add-one algorithm

%% 1. Start with each point; add nearest point to the centroid 
% until doing so doesn't increase the log likelihood ratio anymore

%% 2. Compare across all N starting points to see which yielded best LLR_z

%% 3. Fit threshold on LLR_z

function [bestLLR_z, best_centroid, best_z, best_count] = func_centroidadd(x, y, p_aff)

pigs = [x y];
n = length(x);

LLR_z       = [];
z           = [];
clustpts    = [];
clustidcs   = [];
centroid    = [];
COUNT       = 0;

for i_seed = 1:n
    COUNT = COUNT + 1;

    % Initialize first cluster (single point)
    z              = zeros(1,n);
    z(i_seed)      = 1;
    clustpts       = pigs(i_seed,:);
    clustidcs      = i_seed;
    centroid       = clustpts;

    llr_z          = get_LLR_z_false_affiliation(x,y,z,p_aff);

    tryimprove = 1;

    while tryimprove
        % Find next nearest point to current cluster
        pigs_ = pigs;
        pigs_([clustidcs],:) = inf; % Set previously clustered points to inf
        [~, NNindx] = min(pdist2(centroid,pigs_));

        % Try adding NN to form new cluster
        z_new           = z;
        z_new(NNindx)   = 1;
        clustpts_new    = [clustpts; pigs(NNindx,:)];
        clustidcs_new   = [clustidcs; NNindx];
        centroid_new    = mean(clustpts,1);

        % Get new LLR
        llr_z_new   = get_LLR_z_false_affiliation(x,y,z_new,p_aff);

        if llr_z_new > llr_z
            tryimprove  = 1;
            COUNT = COUNT + 1;

            llr_z       = llr_z_new;
            z           = z_new;
            clustpts    = clustpts_new;
            clustidcs   = clustidcs_new;
            centroid    = centroid_new;
        else
            tryimprove = 0;
        end
    end

    Z{i_seed}           = z;
    Clustpts{i_seed}    = clustpts;
    Clustidcs{i_seed}   = clustidcs;
    Centroid{i_seed}    = centroid;

    LLR_z(i_seed)       = llr_z;       
end

[bestLLR_z, bestseed_idx]          = max(LLR_z);

best_centroid = Centroid{bestseed_idx};
best_z = Z{bestseed_idx};
best_count = COUNT;
