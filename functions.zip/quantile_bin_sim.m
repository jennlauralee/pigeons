%% quantile bins for sim data

function var = quantile_bin_sim(stimtype, feeder)
    % Set quantile upper and lower bounds based on C0 and C1 (1st/ 99th
    % percentile)

    quantiles = [0:4:100];
    
    quant_C1 = prctile(stimtype(find(feeder)), quantiles);
    quant_midpts_C1 = mean([quant_C1(2:end); quant_C1(1:end-1)]);

    quant_C0 = prctile(stimtype(find(~feeder)), quantiles);
    quant_midpts_C0 = mean([quant_C0(2:end); quant_C0(1:end-1)]);
    
    LB = max(quant_C1(1), quant_C0(1));
    UB = min(quant_C1(end), quant_C0(end));
    
    LBcentile = ceil(num2centile(LB, stimtype));
    UBcentile = floor(num2centile(UB, stimtype));
    
    % Set truncated quantiles
    
    trunc_quantiles = linspace(LBcentile,UBcentile,length(quantiles)-2);
    
    quant_ = prctile(stimtype, trunc_quantiles);
    quant = [-inf quant_ inf];
    quant_midpts = mean([quant(2:end); quant(1:end-1)]);
    
    NC1 = histcounts(stimtype(find(feeder)),quant);
    NC0 = histcounts(stimtype(find(~feeder)),quant);
    
    LLR = log(NC1./NC0);
    
    var.LLR             = LLR;
    var.NC1             = NC1;
    var.NC0             = NC0;
    var.quant           = quant;
    var.quant_midpts    = quant_midpts;
    var.quant_C1        = quant_C1;
    var.quant_midpts_C1 = quant_midpts_C1;
    var.quant_C0        = quant_C0;
    var.quant_midpts_C0 = quant_midpts_C0;
end