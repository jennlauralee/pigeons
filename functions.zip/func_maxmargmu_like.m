%% Append maximum marginal likelihood & posterior mu

%clear
%clc

% validate fmincon on this: bads mu, and mu
% validate multiple initiations
% try center of mass initialization

function [LLR_mu_like, mu_like] = func_maxmargmu_like(x,y,p_aff)

init = [0,0];
lb   = [-10, -10];
ub   = [10,10];
plb  = [-10,-10];
pub  = [10,10];

n = length(x);
%OPTIONS = bads('defaults');
%OPTIONS.Display = 'off';
options = optimoptions('fmincon','display','none');
mu_like = fmincon(@(mu) get_marginal_likelihood_mu(mu,x,y,p_aff), init, [],[],[],[], lb, ub,[], options);
%mu_like = bads(@(mu) get_marginal_likelihood_mu(mu,x,y,p_aff), init, lb, ub, plb, pub, [], OPTIONS);

LLR_mu_like = get_LLR_mu_false_affiliation(x,y,mu_like,p_aff);

end


%% append
% clear
% clc
% 
% load('alldata.mat')
% 
% for subjidx = 1:10
%     load(['S' num2str(subjidx) '_maxmargmu.mat']);
%     STIM{subjidx}.maxmargmu = maxmargmu;
% end
% 
% save('alldata.mat', 'DATA', 'STIM');