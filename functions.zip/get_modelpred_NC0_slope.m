%% get N_C0 slope

function NC0_slope = get_modelpred_NC0_slope(N_C0)
load('alldata.mat')

Ns = [6, 9, 12, 15];

for subjidx = 1:length(DATA)
    NC0_slope(subjidx,:) = polyfit(Ns,N_C0(subjidx,:),1);
end

NC0_slope = NC0_slope(:,1);

end