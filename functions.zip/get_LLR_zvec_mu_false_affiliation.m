function LLR_z_mu = get_LLR_zvec_mu_false_affiliation(x,y,zvec,mu,p_aff)
% calculate the LLR for a fixed z and fixed mu. mu given [x,y].

sigma_s = 2;
R       = 10;

n = length(x);

% Get p(x, y | H0)
pxy_H0 = (1/pi/R^2)^n;

% Get p(x, y | H1)
%i_1 = find(zvec); %Indices of affiliated pigeons
n1 = sum(zvec,2); %Number of hypothesized affiliated pigeons
n0 = n - n1; %Number of hypothesized unaffiliated pigeons

term1 = log(p_aff.*normpdf(x, mu(1), sigma_s) .* normpdf(y, mu(2), sigma_s));

LLR_z_mu = zvec*term1 + n0*log((1-p_aff)/pi/R^2) - log(pxy_H0);