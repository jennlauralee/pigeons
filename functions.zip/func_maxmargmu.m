%% Append maximum marginal likelihood & posterior mu

%clear
%clc

%addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));

function [LLR_mu_like, mu_like, LLR_mu_post, mu_post] = func_maxmargmu(x,y,p_aff)

% NTS: probably have to split up likelihood and posterior calculations to
% allow for different p_affs on each model...

% Need to find a way to save the "mu" from the winning fit in order to use
% it on the LLR_z_mu version of this model (with opt_thresh k)

load('alldata.mat')

addpath(genpath('bads-master'));

init = [0,0];
lb   = [-10, -10];
ub   = [10,10];
plb  = [-10,-10];
pub  = [10,10];

n = length(x);

for run = 1 %%%%% CHANGE GET_MARGINAL_LIKELIHOOD_MU and GET_MARGINAL_POSTERIOR_MU to have false p_aff
    [mu_like_run(run,:), NLL_like_run(run)] = bads(@(mu) get_marginal_likelihood_mu(mu,x,y,p_aff), init, lb, ub, plb, pub);
    [mu_post_run(run,:), NLL_post_run(run)] = bads(@(mu) get_marginal_posterior_mu(mu,x,y,p_aff), init, lb, ub, plb, pub);
end

NLL_like_run
NLL_post_run

[~, runidx_like] = min(NLL_like_run);
[~, runidx_post] = min(NLL_post_run);

mu_like = mu_like_run(runidx_like,:);
mu_post = mu_post_run(runidx_post,:);

LLR_mu_like = get_LLR_mu_false_affiliation(x,y,mu_like,p_aff);
LLR_mu_post = get_LLR_mu_false_affiliation(x,y,mu_post,p_aff);    

end


%% append
% clear
% clc
% 
% load('alldata.mat')
% 
% for subjidx = 1:10
%     load(['S' num2str(subjidx) '_maxmargmu.mat']);
%     STIM{subjidx}.maxmargmu = maxmargmu;
% end
% 
% save('alldata.mat', 'DATA', 'STIM');