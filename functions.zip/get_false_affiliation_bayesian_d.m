function [d] = get_false_affiliation_bayesian_d(X, Y, p_aff)
% Gives log posterior ratio (d) based on measurements of x and y

% Input:
% x: x pigeon measurements [nTrials, nPigs]
% y: y pigeon measurement [nTrials, nPigs]
% optional: sig_s, sig

% Output: d (log posterior ratio) [1, nTrials]

%% set parameters

% sig_s =  how far from center does the feeder spawn?
% sig = how far from feeder do pigeons spawn?

sig_s       = 2;
sig         = 2;

pH1         = 0.5;
pH0         = 0.5;
R           = 10;

nTrials = length(X);

for i_trial = 1:nTrials
    x = X{i_trial};
    y = Y{i_trial};
    
    %% calculate p(x,y|z)
    n = size(x,2); % get number of pigeons

    poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors 
    nZ          = length(poss_z);
    % We want to get the likelihood of each possible membership arrangement
    % (z). For each hypothesized z, the feeder (if there is one) could be
    % anywhere.
    % Add the likelihoods up for the feeder being at each location to get the
    % total likelihood of that hypothesized z.

    % Get p(x, y | H0)
    pxy_H0 = (1/pi/R^2)^n;

    % Get p(x, y | H1)
    pxy_H1_ = nan(nZ,1);
    for i_z = 1:length(poss_z)
        z_ = poss_z(i_z,:);
        i_1 = find(z_);
        n1 = sum(z_); %Number of hypothesized affiliated pigeons
        n0 = n - n1; %Number of hypothesized unaffiliated pigeons

        expo_x = -(1/(2*sig^2))*  (sum(x(:,i_1).^2,2) - (sum(x(:,i_1),2).^2 * sig_s^2)/(sig_s^2*n1 + sig^2));
        expo_y = -(1/(2*sig^2))*  (sum(y(:,i_1).^2,2) - (sum(y(:,i_1),2).^2 * sig_s^2)/(sig_s^2*n1 + sig^2));
        pxy_H1_(i_z) = ((1-p_aff)/pi/R^2)^n0 * (p_aff/(2*pi*sig^2))^n1 * sig^2/(n1*sig_s^2 + sig^2) * exp(expo_x + expo_y);
    end

    pxy_H1 = sum(pxy_H1_);

    % Initialize log posterior ratio (d) as log prior ratio
    d(i_trial) = log(pH1 / pH0);
    % Update log posterior ratio (d) using log likelihood ratio if it exists
    if ~any(isnan(pxy_H1))
        d(i_trial) = d(i_trial) + log(pxy_H1 / pxy_H0);
    end
end
end
