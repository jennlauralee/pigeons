%% calc_append_EP

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1%:length(STIM)
    for i_trial = 1:30%:length(STIM{subjidx}.X)
        
        clearvars -except STIM DATA subjidx i_trial
        
        sigma       = 2;
        sigma_s     = 2;
        R           = 10;
        w           = 0.5;


        m0 = [0 0];
        v0 = sigma_s^2;
        
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        n = length(x);
        
        m_i = zeros(n,2);
        v_i(1:n) = inf;
        s_i(1:n) = 1;
        
        m = randn(1,2);
        v = sigma_s^2;

        epsilon = 1e-4;
        delta = epsilon;
        
        counter = 1;
        while delta >= epsilon & counter < 10e8
            for j = 1:n
               x_j = x(j);
               y_j = y(j);
               
               v_old = v;
               m_old = m;
        
               vwoj = 1/(1/v - 1/v_i(j));
               mwoj = [m(1) + (vwoj/v_i(j))*(m(1)-m_i(j,1)) , m(2) + (vwoj/v_i(j))*(m(2)-m_i(j,2))];
               
               Z_j = w * normpdf(mwoj(1), x_j, sqrt(vwoj + sigma^2)) * normpdf(mwoj(2), y_j, sqrt(vwoj + sigma^2)) + (1-w)/(pi*R^2);
               rho_j = 1 - (1-w)/(pi*R^2*Z_j);

               m_new = [mwoj(1) + (rho_j*vwoj/(vwoj + sigma^2))*(x_j-mwoj(1)) , mwoj(2) + (rho_j*vwoj/(vwoj + sigma^2))*(y_j-mwoj(2))];
               v_new = vwoj - rho_j*(vwoj)^2/(vwoj+sigma^2) + (rho_j*(1-rho_j)/2) * (vwoj/(vwoj + sigma^2))^2 * ((x_j-mwoj(1))^2 + (y_j-mwoj(2))^2);
               
               v_i(j) = 1/(1/v_new - 1/vwoj);
               m_i(j,:) = mwoj + ((vwoj + v_i(j))/vwoj) * (m_new - mwoj);

               
               m = m_new;
               v = v_new;
               
               delta = abs(sum(m_old - m_new)) +...
                       abs(v_old - v_new);
               if delta <= epsilon
                   continue
               end
            end
           counter = counter + 1;
        end
        
        for j = 1:n
            s_i(j) = Z_j/ (normpdf(mwoj(1), m_i(j,1), sqrt(vwoj + v_i(j))) * normpdf(mwoj(2), m_i(j,2), sqrt(vwoj + v_i(j))));    
        end
        
        B2ndterm = m0*m0'/v0 +  sum(sum(m_i.^2,2)./v_i');
        
        B = m_new*m_new'/v_new - B2ndterm;
        pD = (v_new/sigma_s^2)*prod(s_i./(2*pi*v_i))*exp(B/2)
        
    end
end
        