%% brute force maximization

function [LLR_z_mu] = func_brute_max_precompute(n,p_aff,precomputed_LLR_trial)

poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors
nZ          = length(poss_z);

for i_z = 1:length(poss_z)
    z_ = poss_z(i_z,:);
    i_1 = find(z_);
    n1 = sum(z_); %Number of hypothesized affiliated pigeons
    n0 = n - n1; %Number of hypothesized unaffiliated pigeons

    LLR_(i_z) = precomputed_LLR_trial(i_z) + log((p_aff^n1)*(1-p_aff)^n0); %get_LLR_z_mu_false_affiliation(x,y,z_,mu_like_(i_z,:), p_aff);
end

LLR_z_mu = max(LLR_);
end