%% plot generic histogram and response curve for distance metrics

function plot_RC(metric, xLabel, xlims, 'Mean)

    %errorbar(metric.quant_midpts_mean, metric.pRespFeeder_mean, metric.pRespFeeder_SEM, 'LineWidth', 2, 'color', 'k'); hold on
    errorbar(metric.quant_midpts_C0_mean, metric.pRespFeeder_C0_mean, metric.pRespFeeder_C0_SEM, 'LineWidth', 2, 'color', 'b'); hold on
    errorbar(metric.quant_midpts_C1_mean, metric.pRespFeeder_C1_mean, metric.pRespFeeder_C1_SEM, 'LineWidth', 2, 'color', 'r'); hold on
    legend({'all', 'C=0', 'C=1'})
    %xlabel(xLabel)
    ylabel('Proportion resp "C=1"')
    xlim(xlims)
    title('Proportion responding feeder present')

end
