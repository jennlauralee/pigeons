%% Append distance betwen closest two points

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        STIM{subjidx}.MinDist(i_trial,1) = min(pdist([x y]));
    end
end

save('alldata.mat', 'DATA', 'STIM');