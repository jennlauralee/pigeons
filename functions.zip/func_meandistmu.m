%% Append the average x and y coordinate as mean dist mu estimate, calc C1_likelihoods

function [LLR_mu, mu] = func_meandistmu(x,y,p_aff)

sigma_s     = 2;

mu = [mean(x) mean(y)];

LLR_mu = get_LLR_mu_false_affiliation(x,y,mu,p_aff);

end