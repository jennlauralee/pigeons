function H = plot_MPdist(varname, Var, MPVar, cc1, cc2, xlims, subdims, i_subplot, ylabelname)

subplot(subdims(1), subdims(2), i_subplot);

Ns = [6,9,12,15];

for i_N = 1:length(Ns)
    HC0(i_N) = errorbar(Var{i_N}.quant_midpts_C0_mean, Var{i_N}.pRespFeeder_C0_mean, Var{i_N}.pRespFeeder_C0_SEM, 'LineStyle', 'none', 'LineWidth', 2, 'color', cc1(i_N,:)); hold on
    myshadedarea(Var{i_N}.quant_midpts_C0_mean, MPVar{i_N}.pRespFeeder_C0_mean, MPVar{i_N}.pRespFeeder_C0_SEM, cc1(i_N,:)); hold on

    HC1 = errorbar(Var{i_N}.quant_midpts_C1_mean, Var{i_N}.pRespFeeder_C1_mean, Var{i_N}.pRespFeeder_C1_SEM, 'LineStyle', 'none', 'LineWidth', 2, 'color', cc2(i_N,:)); hold on
    myshadedarea(Var{i_N}.quant_midpts_C1_mean, MPVar{i_N}.pRespFeeder_C1_mean, MPVar{i_N}.pRespFeeder_C1_SEM, cc2(i_N,:)); hold on
end
%legend(HC0, num2str(Ns'))
xx = xlabel(varname);
set(xx, 'FontSize', 25)

if exist('ylabelname','var')
    hh= ylabel(ylabelname);
    set(hh, 'FontSize', 25);
    set(hh,'FontWeight','bold')
end
%ylabel('Proportion resp "C=1"')
xlim(xlims)
box off
end
