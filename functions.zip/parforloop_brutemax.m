%% parforloop_brutemax

parpool(10);
    
parfor subjidx = 1:10
    calc_append_brute_max(subjidx);
end
