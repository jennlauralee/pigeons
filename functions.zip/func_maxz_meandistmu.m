%% Append local gaussian kernel grid

function [LLR_z_mu] = func_maxz_meandistmu(x,y,p_aff)

[~, mu] = func_meandistmu(x,y,p_aff);
LLR_z_mu = func_maxz(x,y,mu,p_aff);
end

