%% Calc + append EM mu estimate

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/alldata.mat')

EMparams.R       = 10;
EMparams.sigma_s = 2;
EMparams.p_b     = 0.5;

R                = EMparams.R;
sigma_s          = EMparams.sigma_s;
p_b              = EMparams.p_b;

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        n = length(x);
        
        [mux_est, muy_est, hardclass] = EMalgo(x,y,EMparams);
        
        % Record EM estimate of mu
        STIM{subjidx}.EM.mu(i_trial,:) = [mux_est muy_est]; 
       
        % Calculate the log likelihood ratio
        STIM{subjidx}.EM.LLR(i_trial) = get_LLR_mu(x,y,[mux_est muy_est]);
        
        % Record the hard EM z-classification
        STIM{subjidx}.EM.hard.z{i_trial} = hardclass;
        
        % Calculate z-conditioned LLR based on hard EM
        STIM{subjidx}.EM.hard.LLR_z(i_trial,1) = get_LLR_z(x,y,hardclass);
        
        % Calculate z- and mu-conditioned LLR
        STIM{subjidx}.EM.hard.LLR_z_mu(i_trial,1) = get_LLR_z_mu(x,y,hardclass,[mux_est muy_est]);
        
    end
end

save('alldata.mat', 'DATA', 'STIM');