%% func_maxz_maxmargmu_posterior

function [LLR_z_mu] = func_maxz_maxmargmu_posterior(x,y,p_aff)

[~, mu_like] = func_maxmargmu_post(x,y,p_aff);
LLR_z_mu = func_maxz(x,y,mu_like,p_aff);

end