%close all
figd

for subjidx = 1:length(STIM)
    kcount = STIM{subjidx}.k_count.unseededcentroidadd;
    RT = DATA{subjidx}.RT;
    
    scatter(kcount,RT);
    hold on
end