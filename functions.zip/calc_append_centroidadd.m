%% Append centroid-add-one algorithm

%% 1. Start with each point; add nearest point to the centroid 
% until doing so doesn't increase the log likelihood ratio anymore

%% 2. Compare across all N starting points to see which yielded best LLR_z

%% 3. Fit threshold on LLR_z

clear
clc

addpath(genpath('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/'));
load('alldata.mat')

for subjidx = 1:length(STIM)
    for i_trial = 1:length(STIM{subjidx}.X)
        x = STIM{subjidx}.X{i_trial}';
        y = STIM{subjidx}.Y{i_trial}';
        pigs = [x y];
        n = length(x);
        
        LLR_z       = [];
        z           = [];
        clustpts    = [];
        clustidcs   = [];
        centroid    = [];
        COUNT       = 0;
        
        for i_seed = 1:n
            COUNT = COUNT + 1;
            
            % Initialize first cluster (single point)
            z              = zeros(1,n);
            z(i_seed)      = 1;
            clustpts       = pigs(i_seed,:);
            clustidcs      = i_seed;
            centroid       = clustpts;
            
            llr_z          = get_LLR_z(x,y,z);
            
            tryimprove = 1;

            while tryimprove
                % Find next nearest point to current cluster
                pigs_ = pigs;
                pigs_([clustidcs],:) = inf; % Set previously clustered points to inf
                [~, NNindx] = min(pdist2(centroid,pigs_));
                
                % Try adding NN to form new cluster
                z_new           = z;
                z_new(NNindx)   = 1;
                clustpts_new    = [clustpts; pigs(NNindx,:)];
                clustidcs_new   = [clustidcs; NNindx];
                centroid_new    = mean(clustpts,1);
                
                % Get new LLR
                llr_z_new   = get_LLR_z(x,y,z_new);
                
                if llr_z_new > llr_z
                    tryimprove  = 1;
                    COUNT = COUNT + 1;
                    
                    llr_z       = llr_z_new;
                    z           = z_new;
                    clustpts    = clustpts_new;
                    clustidcs   = clustidcs_new;
                    centroid    = centroid_new;
                else
                    tryimprove = 0;
                end
            end
            
            Z{i_seed}           = z;
            Clustpts{i_seed}    = clustpts;
            Clustidcs{i_seed}   = clustidcs;
            Centroid{i_seed}    = centroid;
            
            LLR_z(i_seed)       = llr_z;       
        end
        
        [bestLLR_z, bestseed_idx]          = max(LLR_z);
        [worstLLR_z, worstseed_idx]        = min(LLR_z);
        
        STIM{subjidx}.centroidadd.LLR_z(i_trial,1)     = bestLLR_z;
        STIM{subjidx}.centroidadd.centroid(i_trial,:)  = Centroid{bestseed_idx};
        STIM{subjidx}.centroidadd.z{i_trial}           = Z{bestseed_idx};
        STIM{subjidx}.centroidadd.rand_count(i_trial,1)= COUNT;
        
        STIM{subjidx}.centroidadd.worstseed.LLR_z(i_trial,1)      = worstLLR_z;
        STIM{subjidx}.centroidadd.worstseed.z{i_trial}            = Z{worstseed_idx};
        STIM{subjidx}.centroidadd.worstseed.ratio(i_trial,1)      = worstLLR_z/bestLLR_z;
    end
end

save('alldata.mat', 'DATA', 'STIM');