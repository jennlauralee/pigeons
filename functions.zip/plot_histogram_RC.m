%% plot generic histogram and response curve for distance metrics

function plot_histogram_RC(metric, xLabel, xlims)


errorbar(metric.histcenters(1,:), metric.Nhist_mean, metric.Nhist_SEM, 'LineWidth', 2, 'color', 'k'); hold on
errorbar(metric.histcenters(1,:), metric.Nhist_C0_mean, metric.Nhist_C0_SEM, 'LineWidth', 2, 'color', 'b'); hold on
errorbar(metric.histcenters(1,:), metric.Nhist_C1_mean, metric.Nhist_C1_SEM, 'LineWidth', 2, 'color', 'r'); hold on
legend({'all','C=0','C=1'})
ylabel('N trials')
xlim(xlims)
title('Stimulus distribution')


errorbar(metric.quant_midpts_mean, metric.pRespFeeder_mean, metric.pRespFeeder_SEM, 'LineWidth', 2, 'color', 'k'); hold on
errorbar(metric.quant_midpts_C0_mean, metric.pRespFeeder_C0_mean, metric.pRespFeeder_C0_SEM, 'LineWidth', 2, 'color', 'b'); hold on
errorbar(metric.quant_midpts_C1_mean, metric.pRespFeeder_C1_mean, metric.pRespFeeder_C1_SEM, 'LineWidth', 2, 'color', 'r'); hold on
legend({'all', 'C=0', 'C=1'})
%xlabel(xLabel)
ylabel('Proportion resp "C=1"')
xlim(xlims)
title('Proportion responding feeder present')

% subplot(3,1,3)
% errorbar(metric.quant_midpts_mean, metric.respconf_mean, metric.respconf_SEM, 'LineWidth', 2, 'color', 'k'); hold on
% errorbar(metric.quant_midpts_C0_mean, metric.respconf_C0_mean, metric.respconf_C0_SEM, 'LineWidth', 2, 'color', 'b'); hold on
% errorbar(metric.quant_midpts_C1_mean, metric.respconf_C1_mean, metric.respconf_C1_SEM, 'LineWidth', 2, 'color', 'r'); hold on
% legend({'all', 'C=0', 'C=1'})
% xlabel(xLabel)
% ylabel('Response')
% xlim(xlims)
% ylim([-4 4])
% title('Response with confidence')
