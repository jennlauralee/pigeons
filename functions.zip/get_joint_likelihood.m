function nl_likelihood = get_joint_likelihood(mu,z,x,y)

sigma_s = 2;
R       = 10;

n = length(x);

i_1 = find(z); %Indices of affiliated pigeons
n1 = sum(z); %Number of hypothesized affiliated pigeons
n0 = n - n1; %Number of hypothesized unaffiliated pigeons

nl_likelihood = -sum(log(1/(pi*R^2)^n0 + normpdf(x(i_1),mu(1),sigma_s).*normpdf(y(i_1),mu(2),sigma_s)));
end
