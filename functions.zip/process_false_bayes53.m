%% process false_bayes model 53 results from cluster output
clear
clc

cd('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/false bayes 53/')
listfiles = dir('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/false bayes 53/*.mat');

nlist = length(listfiles);
nsubj = 10;
modelidx = 53;

NLLs = nan(10,10);

for ii = 1:nlist
    load(listfiles(ii).name);
    [sub, run] = find(~cellfun(@isempty,modelresults));
    concat53{sub,run} = modelresults{sub,run};
    NLLs(sub,run) = modelresults{sub,run}.NLL;
end

minNLLs = min(NLLs');
for i_sub = 1:nsubj
    bestrun = find(NLLs(i_sub,:)==minNLLs(i_sub),1);
    Modelresults_{i_sub} = concat53{i_sub,bestrun};
end

%% save in general superstructure
for subjidx = 1:nsubj
    Modelresults{modelidx}.par_est(subjidx,:)   = Modelresults_{subjidx}.par_est;
    Modelresults{modelidx}.NLL(subjidx,:)       = Modelresults_{subjidx}.NLL;
    Modelresults{modelidx}.modelpred(subjidx,:) = Modelresults_{subjidx}.modelpred;
end

path_results = '/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/results/';
save([path_results 'results_' num2str(modelidx) '.mat'],'Modelresults')


