%%calc_append_model_accuracy
function [pcnt_accuracy_sub, pcnt_accuracy_mean] = calc_append_model_accuracy(modelidx,paff)  
    path_results = '/Users/jennlauralee/GitHub Repos/pigeons/Analysis/results';
    addpath(path_results);
    
    if paff
        pafftext = '_paff';
    else
        pafftext = '';
    end
    
    load('alldata.mat')
    load(['results_' num2str(modelidx) pafftext '.mat'])
    
    for subjidx = 1:length(Modelresults{modelidx}.NLL)
        modelpred   = Modelresults{modelidx}.modelpred(subjidx,:);
        modelpredc0 = 1- modelpred;
        feeder      = STIM{subjidx}.Feeder;
        
       pcnt_accuracy_sub(subjidx) = mean([modelpred(find(feeder)) modelpredc0(find(~feeder))]);
    end
    
    pcnt_accuracy_mean = mean(pcnt_accuracy_sub);
end