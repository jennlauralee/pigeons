function H = plot_datadist(varname, Var, cc1, cc2, xlims)

%H = figd;
Ns = [6,9,12,15];

for i_N = 1:length(Ns)
    HC0(i_N) = errorbar(Var{i_N}.quant_midpts_C0_mean, Var{i_N}.pRespFeeder_C0_mean, Var{i_N}.pRespFeeder_C0_SEM, 'LineWidth', 2, 'color', cc1(i_N,:)); hold on

    HC1(i_N) = errorbar(Var{i_N}.quant_midpts_C1_mean, Var{i_N}.pRespFeeder_C1_mean, Var{i_N}.pRespFeeder_C1_SEM, 'LineWidth', 2, 'color', cc2(i_N,:)); hold on

    legend(HC0, num2str(Ns')); hold on
    legend(HC1, num2str(Ns'));
    xlabel(varname)
    ylabel('Proportion resp "C=1"')
    xlim(xlims)
end
end
