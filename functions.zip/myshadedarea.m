function h = myshadedarea(x, y, ysem, mycolour)
% x is a vector, y is a 2-d matrix where the 1st dimension is subjects
% dim (1 or 2) is the dimension that goes on the x-axis

nsubj = size(y,1);
ymean = squeeze(mean(y,1));
ymin  = ymean - ysem;
ymax  = ymean + ysem;

hold on;
for idx = 1:size(y,2)
    h = patch([x x(end:-1:1)], [ymin ymax(end:-1:1)], mycolour); %mycolors(idx,:));
    set(h,'LineStyle', 'none','EdgeColor', mycolour,'FaceAlpha',0.05)
    %set(h,'FaceAlpha',0.3)
end
set(gca,'TickDir','out');