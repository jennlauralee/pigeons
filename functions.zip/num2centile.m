%% number to percentile

function percentile = num2centile(num, set)
    nless = sum(set < num);
    nequal = sum(set == num);
    percentile = 100 * (nless + 0.5*nequal) / length(set);
end