%% calc_append_model_NC0_slope
function [NC0, NC0_slope_sub, NC0_slope_mean] = calc_append_NC0_slope(modelidx, paff)  
path_results = '/Users/jennlauralee/GitHub Repos/pigeons/Analysis/results';
addpath(path_results);

if paff
    pafftext = '_paff';
else
    pafftext = '';
end

load([path_results '/results_' num2str(modelidx) pafftext '.mat'])

NC0 = Modelresults{modelidx}.MP.RF.N_C0;
NC0_slope_sub = get_modelpred_NC0_slope(NC0);
NC0_slope_mean = mean(NC0_slope_sub);
end