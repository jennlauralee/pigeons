%% D_callplotdatawfits_paff

close all
clear
clc

paffmodel = 1;
paffmodels = [39, 40, 43, 44, 45, 46, 47, 49, 50, 51];
path_results = '/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/results/';
path_summstats = '/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/results/allsummstats.mat';

load('/Users/jennlauralee/Google Drive/WedMock/Causal Inference/Analysis/alldata.mat')
for ii = 1:length(paffmodels)
    modelidx = paffmodels(ii);
    load([path_results 'results_' num2str(modelidx) '_paff.mat'])
    D_plotdatawithfits(STIM, DATA, Modelresults, modelidx, path_summstats, paffmodel)
end