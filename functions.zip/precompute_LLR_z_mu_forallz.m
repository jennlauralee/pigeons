%% pre-compute LLR_z_mu for all z's

function [LLR_like_forallz, LLR_post_forallz] = precompute_LLR_z_mu_forallz(x,y)

sig_s       = 2; % how far from center does the feeder spawn?
sig         = 2; % how far from feeder do pigeons spawn?

n = length(x);
poss_z      = permn([0 1],n); %All possible z (pigeon membership) vectors

for i_z = 1:length(poss_z)
    z_ = poss_z(i_z,:);
    i_1 = find(z_);
    n1 = sum(z_); %Number of hypothesized affiliated pigeons
    n0 = n - n1; %Number of hypothesized unaffiliated pigeons

    mu_like_ = [mean(x(i_1)) mean(y(i_1))];
    mu_post_ = [sum(x(i_1))/sig^2 / (1/sig_s^2 + n1/sig^2)  ,  sum(y(i_1))/sig^2 / (1/sig_s^2 + n1/sig^2)];
    
    LLR_like_forallz(i_z) = get_LLR_z_mu(x,y,z_,mu_like_);
    LLR_post_forallz(i_z) = get_LLR_z_mu(x,y,z_,mu_post_);
end

end

