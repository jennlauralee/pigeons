function draw_error_ellipse(mean, covmat, color)
% mean of ellipse
% covariance matrix of data

theta = 0:0.01:(2*pi);
unit_vecs = [cos(theta); sin(theta)];
ellipse = sqrtm(covmat)*unit_vecs./sqrt(10) + mean;
%plot(ellipse(1,:),ellipse(2,:), 'Color', color,'LineWidth', 3); hold on
patch(ellipse(1,:), ellipse(2,:), color, 'FaceAlpha', 0.3,'LineStyle', 'none');
end